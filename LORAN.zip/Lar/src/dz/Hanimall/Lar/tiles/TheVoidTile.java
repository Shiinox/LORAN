package dz.Hanimall.Lar.tiles;

import dz.Hanimall.Lar.graphics.Assets;

public class TheVoidTile extends Tile {

	public TheVoidTile(int id) {
		super(Assets.the_void, id);

	}
	

}

