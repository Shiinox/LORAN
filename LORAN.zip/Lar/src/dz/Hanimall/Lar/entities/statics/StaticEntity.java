package dz.Hanimall.Lar.entities.statics;



import dz.Hanimall.Lar.Game;
import dz.Hanimall.Lar.entities.Entity;
import dz.Hanimall.Lar.worlds.World;

public abstract class StaticEntity extends Entity{
	
		


	public StaticEntity(Game game, World world, float x, float y, int width, int height) {
		super(game, world, x, y, width, height);

		
	}
	
	

}
