package dz.Hanimall.Lar;

public enum Move {

	
	Up,
	UpLeft,
	UpRight,
	Down,
	DownLeft,
	DownRight,
	Right,
	Left,
	
}
