package BDD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connect {
	{
	
	try {
	      Class.forName("com.mysql.jdbc.Driver");
	      System.out.println("Driver O.K.");

	      String url = "jdbc:mysql://localhost/loran";
	      String user = "root";
	      String passwd = "";

	      Connection conn = DriverManager.getConnection(url, user, passwd);
	      System.out.println("Connected");         
	         
	    } catch (Exception e){
	        e.printStackTrace();
	    }      
}
}